"""Fetch + parse listing pages into Mentions, driven by sources.yaml selectors."""
from __future__ import annotations

import time
from typing import Iterator

import requests
import yaml
from bs4 import BeautifulSoup

from .models import Mention


def _now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


def load_config(path: str) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


def _fetch(url: str, cfg: dict) -> str:
    r = cfg["defaults"]["request"]
    headers = {"User-Agent": r["user_agent"]}
    last_exc = None
    for attempt in range(r["retry"]):
        try:
            resp = requests.get(url, headers=headers, timeout=r["timeout_seconds"])
            resp.raise_for_status()
            return resp.text
        except requests.RequestException as e:
            last_exc = e
            time.sleep(r["backoff_seconds"] * (attempt + 1))
    raise RuntimeError(f"fetch failed for {url}: {last_exc}")


def _abs_url(href: str, base: str) -> str:
    if href.startswith("http"):
        return href
    return base.rstrip("/") + "/" + href.lstrip("/")


def scrape_source(source: dict, cfg: dict) -> Iterator[Mention]:
    base = cfg["defaults"]["base_url"]
    sel = source["selectors"]
    html = _fetch(source["list_url"], cfg)
    soup = BeautifulSoup(html, "html.parser")
    now = _now_iso()

    for row in soup.select(sel["row"]):
        link_el = row.select_one(sel["link"])
        title_el = row.select_one(sel["title"])
        date_el = row.select_one(sel["date"])
        if not (link_el and title_el):
            continue
        href = link_el.get("href", "")
        yield Mention(
            source_id=source["id"],
            doc_type=source["doc_type"],
            title=title_el.get_text(strip=True),
            url=_abs_url(href, base),
            date_raw=date_el.get_text(strip=True) if date_el else "",
            scraped_at=now,
        )
    # NOTE: archive-mode pagination handled here once /active selectors confirmed.


def scrape_all(cfg: dict) -> Iterator[Mention]:
    for source in cfg["sources"]:
        if not source.get("enabled"):
            continue
        yield from scrape_source(source, cfg)
